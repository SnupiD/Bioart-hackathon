                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2496028
Joystick gimbal by olukelo is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Joystick gimbal with separate axis loading with curved CAMs. Smooth and precise. For magnetic sensors.

# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/0d/6f/06/cb/6d/1.jpg)

![Alt text](https://cdn.thingiverse.com/assets/19/b5/7a/55/4f/2.jpg)

![Alt text](https://cdn.thingiverse.com/assets/13/01/c7/28/0d/3.jpg)

![Alt text](https://cdn.thingiverse.com/assets/68/96/6c/68/d7/IMG_20170613_161956.jpg)

![Alt text](https://cdn.thingiverse.com/assets/33/be/03/c8/bc/IMG_20170613_172410.jpg)

![Alt text](https://cdn.thingiverse.com/assets/f9/6e/3c/94/f9/IMG_20170622_203306.jpg)

![Alt text](https://cdn.thingiverse.com/assets/df/0c/cd/8f/8a/IMG_20170622_203332.jpg)

![Alt text](https://cdn.thingiverse.com/assets/cf/ad/09/5a/ae/IMG_20170622_203415.jpg)